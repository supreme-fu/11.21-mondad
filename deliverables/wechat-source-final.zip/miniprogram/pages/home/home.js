const api = require('../../services/api');

const glyphs = { cooking: '菜', meeting: '见', reading: '读', outing: '行' };

Page({
  data: { activities: [], records: [], user: null, loading: true, error: '' },
  onShow() { this.load(); },
  onPullDownRefresh() { this.load().finally(() => wx.stopPullDownRefresh()); },
  async load() {
    this.setData({ loading: true, error: '' });
    try {
      const session = await api.ensureSession();
      const [activities, records] = await Promise.all([api.activities(), api.records()]);
      const decorated = activities.map((activity) => {
        const record = records.find((item) => item.activity.id === activity.id && item.participationStatus !== 'left');
        return { ...activity, glyph: glyphs[activity.id] || '事', status: record ? (record.completion ? '已完成' : '已约定') : '' };
      });
      this.setData({ activities: decorated, records, user: session.user, loading: false });
    } catch (error) {
      this.setData({ loading: false, error: error.message || '页面暂时无法加载。' });
    }
  },
  openActivity(event) {
    wx.navigateTo({ url: `/pages/activity/activity?id=${event.currentTarget.dataset.id}` });
  },
});

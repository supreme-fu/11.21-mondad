const api = require('../../services/api');

Page({
  data: { id: '', activity: null, loading: true, pending: false, error: '' },
  onLoad(options) { this.setData({ id: options.id || '' }); this.load(); },
  async load() {
    try {
      const activity = await api.activity(this.data.id);
      this.setData({ activity, loading: false, error: '' });
    } catch (error) { this.setData({ loading: false, error: error.message }); }
  },
  async join() {
    this.setData({ pending: true });
    try {
      await api.join(this.data.id);
      await this.load();
      wx.showToast({ title: '约定已收下', icon: 'success' });
    } catch (error) { this.setData({ error: error.message }); }
    finally { this.setData({ pending: false }); }
  },
  async leave() {
    const id = this.data.activity.participation.id;
    this.setData({ pending: true });
    try { await api.leave(id); await this.load(); }
    catch (error) { this.setData({ error: error.message }); }
    finally { this.setData({ pending: false }); }
  },
  complete() {
    wx.navigateTo({ url: `/pages/complete/complete?participationId=${this.data.activity.participation.id}` });
  },
});
